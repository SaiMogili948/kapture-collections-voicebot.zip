# Kapture Collections Voicebot — "Maya"

Automated outbound Voice AI Collections Agent for Kapture Finance, built on Vapi.ai.

## 📁 Project Structure

```
kapture-collections-voicebot/
├── README.md                    # This file
├── docs/
│   ├── HLD_Document.md          # High-Level Design Document (Task 1)
│   ├── HLD_Document.pdf         # Same document, PDF export (Task 1 submission format)
│   ├── architecture.mmd         # Mermaid architecture diagram source (Task 1)
│   ├── architecture.png         # Rendered diagram (PNG)
│   ├── architecture.svg         # Rendered diagram (SVG)
│   └── demo_script.md           # Two-path script for recording the demo video
├── vapi/
│   ├── system_prompt.txt        # Production Vapi System Prompt
│   ├── tool_definitions.json    # Tool schemas registered in Vapi
│   └── vapi_assistant_config.json  # Full importable assistant config (generated)
├── scripts/
│   └── build_assistant_config.js   # Regenerates the assistant config from prompt + tools
├── mock-server/
│   ├── package.json             # Dependencies
│   ├── server.js                # Express webhook implementation
│   └── .env.example             # Environment variables placeholder
├── tests/
│   ├── test_cases.json              # Evaluation matrix and edge case scenarios
│   ├── run_local_tests.js           # Automated webhook test harness (14 checks)
│   └── headless_call_simulator.js   # Full prompt+LLM+webhook E2E run (no Vapi needed)
```

## 🎯 Overview

**Agent Name:** Maya  
**Client:** Kapture Finance  
**Use Case:** Outbound collections call for overdue EMI (₹8,499, 12 days past due)  
**Target Customer:** Rahul Sharma (Account: ACC-88392)

## 🔧 Setup Instructions

### 1. Mock Webhook Server

```bash
cd mock-server
npm install
cp .env.example .env
# Edit .env if needed (default PORT=3000; valid verification codes 1234,1995)
npm start
```

> **Port note:** if `:3000` is already taken (e.g. another dev server), set `PORT=3100` in `.env`.

Quick self-check — proves the whole backend contract without Vapi:

```bash
node tests/run_local_tests.js   # spawns server, fires Vapi-style tool calls, 14/14 checks
```

Full conversation-level run (real prompt + LLM + webhook, no Vapi) — see [Headless E2E](#-headless-end-to-end-run-verified-no-vapi-needed):

```bash
node tests/headless_call_simulator.js TC-003   # requires local Ollama; defaults: llama3.1:8b
```

### 2. Expose via ngrok

```bash
ngrok http 3000
```

Copy the HTTPS URL (e.g., `https://abc123.ngrok-free.app/webhook`) — this goes into Vapi tool webhooks.

### 3. Vapi Assistant Configuration

**Fastest path — import the prebuilt config:**

1. Sign up at [vapi.ai](https://vapi.ai) (free tier)
2. **Assistants → Create Assistant**, then use **Advanced → Import JSON** (or `POST /assistant` via the API)
3. Paste the contents of `vapi/vapi_assistant_config.json`
4. One edit required: replace `YOUR-NGROK-SUBDOMAIN` in every tool's `server.url` with your ngrok URL

This already sets: Deepgram `nova-2` transcriber, GPT-4o @ 0.1 temperature, ElevenLabs `Sarah` voice, the first message, system prompt, all 5 tools, 5-min duration cap, and end-call phrases.

**Manual path (dashboard):**

1. **Assistants → Create Assistant → Blank Template**
2. **Transcriber:** Deepgram → Model: `nova-2` → Language: `en-US` (use `multi` if Hindi is missed on your build)
3. **Model:** OpenAI → `gpt-4o` (or `gpt-4o-mini`) → Temperature: `0.1`
4. **Voice:** ElevenLabs → Voice ID: `Sarah` (or similar professional female)
5. **First Message:** 
   ```
   Hello, this is Maya calling from Kapture Finance. This call may be recorded for quality and compliance purposes. Am I speaking with Mr. Rahul Sharma?
   ```
6. **Tools Tab:** Add 5 functions from `vapi/tool_definitions.json` with webhook URL:
   - `verify_customer`, `log_promise_to_pay`, `send_payment_link`, `escalate_to_agent`, `mark_disposition`
7. **System Prompt:** Paste contents of `vapi/system_prompt.txt`

> If you later edit the prompt or tools, re-run `node scripts/build_assistant_config.js` to regenerate the import file.

### 4. Test Call

- Use Vapi **Web Call** button for quick testing
- Or trigger outbound call via Vapi Dashboard / API

---

## 🎨 Design Choices & Rationale

| Component | Choice | Reason |
|-----------|--------|--------|
| **LLM** | GPT-4o | Best reasoning for state enforcement, low latency, handles Hindi/English |
| **STT** | Deepgram Nova-2 | Optimized for telephony, multi-language, <200ms latency |
| **TTS** | ElevenLabs (Sarah) | Natural conversational tone, expressive, Indian accent support |
| **Temperature** | 0.1 | Strict compliance adherence, deterministic tool calling |
| **State Machine** | Tool-enforced | Auth gate locked behind `verify_customer` tool response — not prompt-discretionary |

---

## 🐛 Debugging Log

| Issue | Root Cause | Fix |
|-------|------------|-----|
| Bot disclosed debt before auth | LLM ignored prompt instructions | Added explicit STATE 0/1/2/3/4 labels + "DO NOT proceed until tool response" |
| Tool call not firing | Vapi expects `results[].toolCallId` | Fixed server response format to match Vapi spec |
| Hindi not understood | Transcriber set to `en-US` only | Changed to `multi` language for Hindi/English mix |
| ngrok URL changes on restart | Free tier random subdomain | Use `ngrok http --domain=your-fixed-domain.ngrok-free.app 3000` (requires auth) |
| Call ends abruptly | Missing `mark_disposition` in all branches | Added disposition call to every terminal state |
| LLM fired `verify_customer` with an empty code | Model called the tool before the customer spoke; empty attempt burned the retry budget | Server-side guardrail: empty code returns `attempt_counted: false` + explicit re-ask instruction (verified in live run) |
| Small local LLM printed tool calls as text | llama3.1:8b cannot reliably emit `tool_calls` JSON on complex flows | Use GPT-4o-class model in production; server validates every tool payload |
| Only the first of several batched tool calls was executed | Vapi batches multiple `toolCalls` in one webhook; server used `toolCalls?.[0]` | Refactored `/webhook` to loop over every tool call and return a `results` entry for each `toolCallId` (verified live with a 3-call batch) |

---

## 🧪 Headless End-to-End Run (verified, no Vapi needed)

`tests/headless_call_simulator.js` drives the **real system prompt** through an LLM and routes every tool call through the **real webhook server over HTTP** — the exact contract Vapi uses. Run with:

```bash
node tests/headless_call_simulator.js TC-002   # or TC-003 / TC-004 / TC-008
```

Live results (llama3.1:8b via Ollama, temperature 0.1):

| Scenario | Result |
|----------|--------|
| **TC-002 Happy Path (PTP)** | Auth gate held (no debt before `verified: true`), empty-code guardrail triggered → re-ask, ₹8,499 disclosed after auth, `log_promise_to_pay(2026-08-14, 8499)` executed, closing delivered. Model emitted `send_payment_link` as text on one turn (8b limitation) so `PTP_AGREED` disposition was not logged. |
| **TC-003 Already Paid** | ✅ Full pass — auth → disclosure → claim → `mark_disposition(ALREADY_PAID)` with UPI ref in notes. |
| **TC-004 Do Not Call** | ✅ Full pass — auth → disclosure → request → `mark_disposition(DO_NOT_CALL)` → compliant end. |
| **TC-008 Verification Failure** | ✅ Compliant behavior — two wrong codes refused, **zero debt disclosed**, call ended politely. Model printed the final disposition call as text (8b limitation), so `WRONG_PERSON` was not executed. |

**Takeaway:** the pipeline, state gating, guardrails and tools work end-to-end. The two incomplete dispositions are a model-capability artifact (small local 8b model); a GPT-4o-class model executes all tool calls reliably — this is exactly why the production config uses GPT-4o @ 0.1. Re-run any scenario with `OLLAMA_MODEL` set to a stronger model to confirm.

---

## 🚀 Future Enhancements

1. **Real Payment Integration** — Razorpay/Stripe payment links via `send_payment_link`
2. **Bilingual Prompt Engineering** — Separate Hindi system prompt, dynamic language detection
3. **Call Analytics Dashboard** — Store call transcripts, tool calls, outcomes in DB (PostgreSQL)
4. **Retry/Callback Scheduling** — Vapi `schedule_call` for "call me tomorrow" requests
5. **A/B Testing Framework** — Prompt variants, voice variants, measure PTP rate
6. **Compliance Audit Logs** — Immutable logs for RBI audit trail
7. **Voicemail Detection** — Deepgram voicemail model → auto-disposition `VOICEMAIL`

---

## 📞 Demo Scenarios Recorded

Follow `docs/demo_script.md` to record the 2–4 minute Loom. It contains the full word-for-word script and expected server logs for:

1. **Happy Path (PTP):** Greeting → Auth (1234) → Debt disclosure → "Pay Friday" → PTP logged → SMS link sent → Close
2. **Edge Case (Already Paid):** Auth → Debt disclosure → "Paid yesterday UPI" → `ALREADY_PAID` disposition → Processing info → Close
3. **Bonus (DNC):** "Stop calling me" → `DO_NOT_CALL` disposition → Immediate termination

**Recording link:** *(paste Loom/Vapi call link here after recording)*

---

## 📄 Submission Checklist

- [x] HLD Document (`docs/HLD_Document.md`) + architecture diagram (`docs/architecture.mmd`)
- [x] Vapi System Prompt (`vapi/system_prompt.txt`)
- [x] Importable Assistant Config (`vapi/vapi_assistant_config.json`)
- [x] Tool Definitions (`vapi/tool_definitions.json`)
- [x] Mock Server (`mock-server/server.js`) — verified: 14/14 automated checks pass
- [x] Test Cases (`tests/test_cases.json`) + automated harness (`tests/run_local_tests.js`) + headless E2E simulator (`tests/headless_call_simulator.js`)
- [x] Demo Script (`docs/demo_script.md`)
- [x] README (this file)
- [ ] Demo Recording (Loom/Vapi call link) — record per `docs/demo_script.md`, then paste link above