# High-Level Design Document
## Kapture Finance — Outbound Collections Voicebot "Maya"

**Version:** 1.0  
**Date:** 2026-08-12  
**Author:** AI Delivery Intern Candidate  
**Status:** For Engineering Handoff

---

## 1. Architecture & Pipeline

![Architecture Diagram — Maya Collections Voicebot](architecture.png)

*Mermaid source: [`architecture.mmd`](architecture.mmd) (renders on GitHub / mermaid.live).*

### 1.1 System Overview

```
┌─────────────┐     ┌──────────┐     ┌─────────────┐     ┌────────────┐     ┌──────────┐
│  Customer   │────▶│ Telephony│────▶│    STT      │────▶│ Orchestrator│────▶│   TTS    │
│  (Phone)    │     │  (SIP/   │     │ (Deepgram   │     │  (GPT-4o)  │     │(ElevenLabs)│
└─────────────┘     │   PSTN)  │     │  Nova-2)    │     │            │     └────┬─────┘
                    └──────────┘     └─────────────┘     └─────┬──────┘           │
                                                                 │                │
                                         ┌──────────────────────┼────────────────┘
                                         ▼                      ▼
                                  ┌─────────────┐        ┌─────────────┐
                                  │  Mock API   │        │  Datastore  │
                                  │  (Webhook)  │        │  (PostgreSQL/│
                                  │             │        │   Redis)    │
                                  └─────────────┘        └─────────────┘
```

### 1.2 Component Selection & Rationale

| Component | Technology | Selection Rationale |
|-----------|------------|---------------------|
| **Telephony** | Vapi.ai (SIP/PSTN) | Managed infrastructure, built-in STT/LLM/TTS orchestration, free trial credits |
| **STT / Transcriber** | Deepgram Nova-2 | Telephony-optimized, 8kHz audio support, multi-language (EN/HI), <200ms latency |
| **LLM / Orchestrator** | OpenAI GPT-4o (temp 0.1) | Best reasoning for state enforcement, function calling reliability, Hindi/English bilingual |
| **TTS / Voice** | ElevenLabs "Sarah" | Expressive, natural conversational tone, Indian English accent support, low latency |
| **Mock API** | Node.js/Express on Render/ngrok | Simple webhook endpoint for Vapi tool calls, stateless mock responses |
| **Datastore** | PostgreSQL (prod) / In-memory (mock) | ACID for disposition logs, Redis for session state |

### 1.3 Latency Budget (End-to-End Target: < 1.2s)

| Hop | Target | Measurement Point | Notes |
|-----|--------|-------------------|-------|
| **Telephony → STT** | 150ms | Audio first byte to transcript chunk | Deepgram streaming, 8kHz opus |
| **STT → LLM First Token** | 400ms | Transcript final → LLM first token | Includes Vapi orchestration overhead |
| **LLM Processing** | 300ms | First token → tool call / response | Temp 0.1, short context, few tools |
| **Tool Call (Mock API)** | 100ms | LLM tool call → HTTP response | Local ngrok/Render, <50ms typical |
| **TTS Synthesis** | 200ms | Text → audio first byte | ElevenLabs streaming, chunked |
| **TTS → Telephony Out** | 50ms | Audio chunk → customer ear | Network jitter buffer |
| **TOTAL** | **~1.2s** | **Customer speech → bot audio** | P95 target, excludes human thinking time |

**Monitoring:** Vapi dashboard latency metrics + custom logs at each tool call boundary.

---

## 2. Conversation Flow / State Machine

### 2.1 State Diagram

```
┌─────────┐
│  INIT   │──(Call Connected)──▶┌─────────────┐
└─────────┘                     │    GREETING │
                                │  (STATE 0)  │
                                └──────┬──────┘
                                       │
                    ┌──────────────────┼──────────────────┐
                    ▼                  ▼                  ▼
              ┌────────────┐    ┌──────────────┐   ┌─────────────┐
              │ "Yes, this │    │ "No/ Wrong   │   │ Voicemail/  │
              │  is Rahul" │    │  Person"     │   │ No Input    │
              └─────┬──────┘    └──────┬───────┘   └──────┬──────┘
                    │                  │                  │
                    ▼                  ▼                  ▼
              ┌─────────────┐   ┌─────────────┐   ┌─────────────┐
              │ AUTH_PENDING│   │WRONG_PERSON │   │  NO_RESPONSE│
              │  (STATE 1)  │   │  DISPOSITION│   │  DISPOSITION│
              └──────┬──────┘   └─────────────┘   └─────────────┘
                     │
         ┌───────────┴───────────┐
         ▼                       ▼
┌────────────────┐        ┌────────────────┐
│ verify_customer│        │ verify_customer│
│  returns OK    │        │  returns FAIL  │
└───────┬────────┘        └───────┬────────┘
        │                         │
        ▼                         ▼
┌───────────────┐         ┌───────────────┐
│ AUTHENTICATED │         │  AUTH_FAILED  │
│  (STATE 2)    │         │  (retry 1x →  │
└───────┬───────┘         │  WRONG_PERSON)│
        │               └───────────────┘
        ▼
┌─────────────────┐
│  NEGOTIATION    │
│   (STATE 3)     │
└───────┬─────────┘
        │
  ┌─────┼─────┬─────────────┬──────────────┬────────────┐
  ▼     ▼     ▼             ▼              ▼            ▼
PTP   HARD-  ALREADY    DISPUTE       DNC/          ABUSIVE
      SHIP    PAID                   OPTOUT
  ▼     ▼     ▼             ▼              ▼            ▼
┌─────────────────────────────────────────────────────────────┐
│                    ACTION EXECUTION (STATE 4)               │
│  log_promise_to_pay / send_payment_link / escalate_to_agent │
│                          │                                  │
                          ▼
                 ┌───────────────┐
                 │  WRAP_UP &    │
                 │  DISPOSITION  │
                 │   (STATE 5)   │
                 └───────┬───────┘
                         │
                         ▼
                  ┌─────────────┐
                  │  CALL_ENDED │
                  └─────────────┘
```

### 2.2 State Definitions & Transition Locks

| State | Name | Entry Condition | Exit Condition (Lock) | Allowed Actions |
|-------|------|-----------------|----------------------|-----------------|
| **S0** | GREETING | Call connected | User confirms "Yes, I'm Rahul" | Ask identity, no debt mention |
| **S1** | AUTH_PENDING | User claims target identity | `verify_customer` returns `verified: true` | Ask PAN/DOB, **block debt disclosure** |
| **S2** | AUTHENTICATED | Tool `verify_customer` success | Debt disclosed + user responds | Disclose debt, negotiate |
| **S3** | NEGOTIATION | Debt disclosed | Tool call executed (PTP/escalate/disposition) | Collect PTP, handle objections |
| **S4** | ACTION_EXECUTION | User intent captured | Tool response received | Call appropriate tool(s) |
| **S5** | WRAP_UP | Action complete | `mark_disposition` logged | Final pleasantries, end call |
| **S6** | CALL_ENDED | Disposition logged | — | Terminal state |

**Critical Enforcement:** Transition S1 → S2 is **hard-locked** behind `verify_customer` tool response. The LLM prompt explicitly forbids debt disclosure until tool returns `verified: true`. No prompt engineering alone — the state machine is enforced by tool gating.

---

## 3. Intents & Entities

### 3.1 Intent Taxonomy

| Intent | Description | Trigger Phrases (EN/HI) | Required Entities | Next State |
|--------|-------------|-------------------------|-------------------|------------|
| `CONFIRM_IDENTITY` | User confirms they are target | "Yes", "Haan main Rahul hoon", "Speaking" | — | S1 → S2 (after verify) |
| `DENY_IDENTITY` | Wrong person / not target | "No", "Wrong number", "Woh nahi hain" | — | S0 → WRONG_PERSON |
| `PROVIDE_VERIFICATION` | User gives PAN/DOB | "1234", "1995", "PAN last four 1234" | `verification_code` | S1 (tool call) |
| `PROMISE_TO_PAY` | Commits to payment date/amount | "I'll pay Friday", "Kal de dunga", "Next week" | `ptp_date`, `ptp_amount` | S3 → S4 |
| `ALREADY_PAID` | Claims payment already made | "Already paid", "Kal UPI kiya", "Settled" | `payment_ref` (optional), `payment_date` | S3 → S4 |
| `HARDSHIP` | Cannot pay full amount | "Can't pay", "Financial difficulty", "Paise nahi hain" | `hardship_reason` | S3 → S4 (escalate) |
| `DISPUTE` | Disputes debt validity/amount | "Wrong amount", "Dispute", "Maine nahi liya" | `dispute_reason` | S3 → S4 (escalate) |
| `REQUEST_CALLBACK` | Wants call later | "Call tomorrow", "Baad mein call karo" | `callback_date`, `callback_time` | S3 → S4 (schedule) |
| `REQUEST_DNC` | Do-not-call opt-out | "Stop calling", "Do not call list", "Band karo" | — | S3 → S4 (DNC disposition) |
| `ABUSIVE` | Threats, profanity, hostility | Abusive language detected | — | S3 → S4 (warning → end) |

### 3.2 Entity Definitions

| Entity | Type | Format/Validation | Examples |
|--------|------|-------------------|----------|
| `verification_code` | String | 4 digits (PAN) OR 4 digits (birth year) | "1234", "1995" |
| `ptp_date` | String (ISO-8601) | YYYY-MM-DD, or "tomorrow", "Friday" → normalized | "2026-08-14", "this Friday" |
| `ptp_amount` | Number | INR, ≤ overdue amount (₹8,499) | 8499, 5000 |
| `payment_ref` | String | UPI ref / TXN ID / free text | "UPI123456", "Yesterday 3pm" |
| `hardship_reason` | String | Free text, categorized later | "Job loss", "Medical emergency" |
| `dispute_reason` | String | Free text | "Wrong amount", "Already closed" |
| `callback_date` | String (ISO-8601) | Normalized from relative dates | "2026-08-13" |

---

## 4. Tools / API Calls

All tools are exposed as Vapi function definitions with webhook endpoints. Mock server returns deterministic responses for demo.

### 4.1 Tool Specifications

#### `verify_customer`
```json
{
  "name": "verify_customer",
  "description": "Verifies customer identity using last 4 digits of PAN or birth year. MUST be called before any debt disclosure.",
  "parameters": {
    "type": "object",
    "properties": {
      "account_id": { "type": "string", "description": "Customer account ID, e.g., ACC-88392" },
      "verification_code": { "type": "string", "description": "4-digit PAN suffix or birth year provided by user" }
    },
    "required": ["account_id", "verification_code"]
  },
  "returns": {
    "type": "object",
    "properties": {
      "verified": { "type": "boolean" },
      "customer_name": { "type": "string" },
      "message": { "type": "string" }
    }
  }
}
```
**Mock Logic:** Returns `verified: true` for codes "1234" or "1995"; else `false`.

---

#### `log_promise_to_pay`
```json
{
  "name": "log_promise_to_pay",
  "description": "Records the customer's Promise-to-Pay commitment with date and amount.",
  "parameters": {
    "type": "object",
    "properties": {
      "account_id": { "type": "string" },
      "ptp_date": { "type": "string", "description": "ISO-8601 date or natural language (normalized server-side)" },
      "amount": { "type": "number", "description": "Committed amount in INR" }
    },
    "required": ["account_id", "ptp_date", "amount"]
  },
  "returns": {
    "type": "object",
    "properties": {
      "success": { "type": "boolean" },
      "ptp_id": { "type": "string" },
      "confirmed_date": { "type": "string" },
      "amount": { "type": "number" }
    }
  }
}
```

---

#### `send_payment_link`
```json
{
  "name": "send_payment_link",
  "description": "Triggers payment link delivery via SMS/WhatsApp to registered mobile.",
  "parameters": {
    "type": "object",
    "properties": {
      "account_id": { "type": "string" },
      "channel": { "type": "string", "enum": ["SMS", "WhatsApp", "BOTH"] }
    },
    "required": ["account_id", "channel"]
  },
  "returns": {
    "type": "object",
    "properties": {
      "success": { "type": "boolean" },
      "message": { "type": "string" },
      "link_id": { "type": "string" }
    }
  }
}
```

---

#### `escalate_to_agent`
```json
{
  "name": "escalate_to_agent",
  "description": "Transfers call to human agent queue with context and reason.",
  "parameters": {
    "type": "object",
    "properties": {
      "account_id": { "type": "string" },
      "reason": { "type": "string", "enum": ["HARDSHIP", "DISPUTE", "COMPLEX_QUERY", "CUSTOMER_REQUEST"] },
      "summary": { "type": "string", "description": "Brief context for agent handoff" }
    },
    "required": ["account_id", "reason", "summary"]
  },
  "returns": {
    "type": "object",
    "properties": {
      "success": { "type": "boolean" },
      "ticket_id": { "type": "string" },
      "queue_position": { "type": "number" },
      "estimated_wait_seconds": { "type": "number" }
    }
  }
}
```

---

#### `mark_disposition`
```json
{
  "name": "mark_disposition",
  "description": "Logs final call outcome. MUST be called in every terminal path.",
  "parameters": {
    "type": "object",
    "properties": {
      "account_id": { "type": "string" },
      "status": {
        "type": "string",
        "enum": [
          "PTP_AGREED",
          "ALREADY_PAID",
          "DISPUTED",
          "HARDSHIP_ESCALATED",
          "WRONG_PERSON",
          "DO_NOT_CALL",
          "NO_RESPONSE",
          "VOICEMAIL",
          "ABUSIVE_TERMINATED",
          "CALLBACK_SCHEDULED"
        ]
      },
      "notes": { "type": "string" }
    },
    "required": ["account_id", "status"]
  },
  "returns": {
    "type": "object",
    "properties": {
      "success": { "type": "boolean" },
      "disposition_logged": { "type": "string" },
      "timestamp": { "type": "string", "format": "date-time" }
    }
  }
}
```

### 4.2 Tool Call Sequence by Path

| Path | Tool Sequence |
|------|---------------|
| **Happy Path (PTP)** | `verify_customer` → `log_promise_to_pay` → `send_payment_link` → `mark_disposition(PTP_AGREED)` |
| **Already Paid** | `verify_customer` → `mark_disposition(ALREADY_PAID)` |
| **Hardship** | `verify_customer` → `escalate_to_agent(HARDSHIP)` → `mark_disposition(HARDSHIP_ESCALATED)` |
| **Dispute** | `verify_customer` → `escalate_to_agent(DISPUTE)` → `mark_disposition(DISPUTED)` |
| **DNC** | `verify_customer` → `mark_disposition(DO_NOT_CALL)` |
| **Wrong Person** | `mark_disposition(WRONG_PERSON)` (no verify needed) |
| **No Input/Voicemail** | `mark_disposition(NO_RESPONSE)` / `mark_disposition(VOICEMAIL)` |

---

## 5. Auth & Data Safety

### 5.1 Identity Verification Protocol

1. **Zero-Debt-Disclosure Rule:** The system prompt and state machine **strictly prohibit** mentioning any of the following before `verify_customer` returns `verified: true`:
   - "overdue", "overdue by", "days past due", "DPD"
   - "EMI", "loan", "personal loan", "amount", "₹"
   - "Kapture Finance debt", "payment due", "outstanding"

2. **Verification Factors (2FA-lite):**
   - **Primary:** Last 4 digits of PAN card (Indian tax ID)
   - **Fallback:** Year of birth (YYYY)
   - Both are low-sensitivity, customer-known, not easily guessable by third parties

3. **Third-Party Protection:**
   - If non-target answers: "Is Mr. Rahul Sharma available?" → No debt mention
   - If target unavailable: Schedule callback, no details left on voicemail
   - Voicemail detection → Disposition `VOICEMAIL`, no debt in message

### 5.2 Data Handling

| Data | In Transit | At Rest (Mock) | At Rest (Prod) | Logs |
|------|------------|----------------|----------------|------|
| PAN suffix / DOB | TLS 1.2+ | In-memory only | Encrypted (AES-256) | **Masked**: `PAN: ****1234` |
| Payment commitment | TLS 1.2+ | In-memory | Encrypted + PCI DSS | Full (audit) |
| Call recording | SRTP | N/A | Encrypted storage | Access-controlled |
| Disposition logs | TLS 1.2+ | In-memory | PostgreSQL + audit table | Full |

### 5.3 PII Masking in Logs

```
# Raw log (internal)
{ "account_id": "ACC-88392", "verification_code": "1234", "customer_name": "Rahul Sharma" }

# Emitted log (observability)
{ "account_id": "ACC-88392", "verification_code": "****", "customer_name": "Rahul S****" }
```

---

## 6. Guardrails & Compliance

### 6.1 Regulatory Framework (India/RBI Fair Practices Code)

| Requirement | Implementation |
|-------------|----------------|
| **Calling Hours** | 08:00–19:00 IST only. Vapi `schedule_call` respects TZ. Outbound dialer checks `hour(now())` before dial. |
| **Self/Company Disclosure** | Mandatory first utterance: "Hello, this is Maya calling from Kapture Finance." |
| **Purpose Disclosure** | After auth: "I'm calling regarding your Kapture Finance personal loan..." |
| **No Third-Party Disclosure** | Auth gate (Section 5) enforces this technically. |
| **Opt-Out / DNC** | Immediate `mark_disposition(DO_NOT_CALL)` on request. Synced to central DNC registry (prod). |
| **No Threats/Harassment** | Prompt: "Never threaten legal action, credit bureau reporting beyond facts, or use abusive language." |
| **Call Recording Notice** | "This call may be recorded for quality and compliance." (First message or IVR pre-connect) |

### 6.2 LLM Guardrails (Prompt-Level)

```markdown
## HALLUCINATION PREVENTION
- NEVER invent payment options not in tool schema (e.g., "50% waiver", "zero interest").
- NEVER state legal consequences beyond: "may impact credit score" (factual).
- If unsure → "Let me connect you with a specialist" (escalate_to_agent).

## OFF-TOPIC HANDLING
- User asks about other products → "I'm here to discuss your overdue EMI. For other queries, visit kapturefinance.com"
- User asks personal questions → Polite redirect: "Let's focus on your account today."

## TONE GUARDRAILS
- Empathetic but firm. No apologizing for the debt.
- "I understand" → OK. "I'm sorry you owe money" → NOT OK.
```

### 6.3 Technical Guardrails

| Guardrail | Mechanism |
|-----------|-----------|
| **Auth before disclosure** | State machine lock (S1→S2 gated by tool) |
| **Tool schema validation** | Vapi enforces JSON schema; invalid args rejected |
| **Max retries** | Verification: 2 attempts → WRONG_PERSON; No input: 2 re-prompts → NO_RESPONSE |
| **Call duration cap** | 5 minutes max → auto-wrap with `mark_disposition` |
| **Profanity filter** | Regex on transcript → warning → `ABUSIVE_TERMINATED` |

---

## 7. Edge Cases Matrix

| # | Scenario | Detection | Handling | Disposition |
|---|----------|-----------|----------|-------------|
| **1** | **Already Paid** | User claims payment post-auth | Ask ref/date → `mark_disposition(ALREADY_PAID)` → Inform 24-48hr processing | `ALREADY_PAID` |
| **2** | **Disputes Amount** | "Wrong amount", "Don't recognize" | Empathize → `escalate_to_agent(DISPUTE)` → `mark_disposition(DISPUTED)` | `DISPUTED` |
| **3** | **Wrong Number** | "Wrong person", "Not Rahul" (pre-auth) | "Is Rahul available?" → If no: `mark_disposition(WRONG_PERSON)` | `WRONG_PERSON` |
| **4** | **Do-Not-Call** | "Stop calling", "DNC list" (post-auth) | Acknowledge → `mark_disposition(DO_NOT_CALL)` → Immediate hangup | `DO_NOT_CALL` |
| **5** | **Voicemail** | Deepgram voicemail model / silence > 10s | No debt in message → `mark_disposition(VOICEMAIL)` | `VOICEMAIL` |
| **6** | **No Input / Timeout** | 2x re-prompt, no speech detected | "I didn't catch that" ×2 → `mark_disposition(NO_RESPONSE)` | `NO_RESPONSE` |
| **7** | **Abusive Caller** | Profanity/threats detected | 1 warning: "Please keep it respectful" → 2nd: `mark_disposition(ABUSIVE_TERMINATED)` | `ABUSIVE_TERMINATED` |
| **8** | **Language Switch (EN↔HI)** | Hindi detected in transcript | Continue in detected language; prompt has bilingual examples | Same state |
| **9** | **Partial Payment Offer** | "Can pay 5000 now" | Accept if ≤ overdue → `log_promise_to_pay(amount: 5000)` | `PTP_AGREED` |
| **10** | **Callback Request** | "Call me tomorrow at 5" | Parse date/time → `mark_disposition(CALLBACK_SCHEDULED)` + schedule | `CALLBACK_SCHEDULED` |

---

## 8. Escalation & Disposition

### 8.1 Escalation Triggers

| Trigger | Escalation Type | Agent Queue | Context Passed |
|---------|----------------|-------------|----------------|
| Hardship claim | Warm transfer | Collections Specialist | Account, hardship reason, income info if shared |
| Dispute debt | Warm transfer | Grievance/Resolution Desk | Account, dispute details, loan docs ref |
| Complex query (legal, settlement >10%) | Warm transfer | Senior Collector | Full transcript, account history |
| Customer requests human | Warm transfer | Next available | "Customer requested human agent" |

**Warm Transfer Protocol:** Bot says "Transferring you to a specialist who can help better. Please hold." → `escalate_to_agent` → Vapi bridges to SIP queue.

### 8.2 Disposition Codes (Final)

| Code | Meaning | Counts as Contained? |
|------|---------|---------------------|
| `PTP_AGREED` | Promise to pay logged, link sent | ✅ Yes |
| `ALREADY_PAID` | Customer claims paid | ✅ Yes |
| `DISPUTED` | Escalated for dispute | ❌ No (human needed) |
| `HARDSHIP_ESCALATED` | Escalated for hardship | ❌ No |
| `WRONG_PERSON` | Not target customer | ✅ Yes |
| `DO_NOT_CALL` | Opt-out registered | ✅ Yes |
| `NO_RESPONSE` | Timeout/no input | ✅ Yes |
| `VOICEMAIL` | Reached voicemail | ✅ Yes |
| `ABUSIVE_TERMINATED` | Caller abusive, ended | ✅ Yes |
| `CALLBACK_SCHEDULED` | Future call booked | ✅ Yes |

---

## 9. Observability

### 9.1 Key Metrics (Dashboard)

| Metric | Definition | Target | Alert Threshold |
|--------|------------|--------|-----------------|
| **Containment Rate** | % calls ending in contained disposition (PTP, ALREADY_PAID, WRONG_PERSON, DNC, NO_RESPONSE, VOICEMAIL, ABUSIVE, CALLBACK) / total calls | > 75% | < 60% |
| **PTP Rate** | `PTP_AGREED` / (authenticated calls) | > 35% | < 20% |
| **First Call Resolution (FCR)** | Contained dispositions / authenticated calls | > 70% | < 50% |
| **Auth Success Rate** | `verify_customer=true` / `verify_customer` called | > 85% | < 70% |
| **Avg Call Duration** | Connect to disconnect (authenticated) | 180–240s | > 300s |
| **End-to-End Latency (P95)** | Customer speech → bot audio | < 1.2s | > 1.5s |
| **Drop Rate** | Caller hangs up before disposition | < 5% | > 10% |
| **Escalation Rate** | (DISPUTED + HARDSHIP) / authenticated | < 25% | > 40% |
| **DNC Rate** | DO_NOT_CALL / total | < 2% | > 5% |

### 9.2 Logging Schema (Structured JSON)

```json
{
  "timestamp": "2026-08-12T14:32:15.123Z",
  "call_id": "vapi_call_abc123",
  "account_id": "ACC-88392",
  "state": "NEGOTIATION",
  "event": "tool_call",
  "tool": "log_promise_to_pay",
  "input": { "ptp_date": "2026-08-14", "amount": 8499 },
  "output": { "success": true, "ptp_id": "PTP-9921" },
  "latency_ms": 87,
  "transcript_segment": "I'll pay this Friday"
}
```

### 9.3 Debugging Signals

| Signal | Source | Action |
|--------|--------|--------|
| Tool call failures | Mock server logs / Vapi dashboard | Check webhook URL, schema, response format |
| High latency | Vapi analytics | Check STT/TTS provider status, network |
| Low auth rate | Disposition logs | Verify PAN/DOB prompt clarity, retry logic |
| Hallucination | Transcript review | Tighten prompt, add few-shot examples |
| Language issues | Transcript + STT confidence | Enable `multi` language, add Hindi prompt variants |

### 9.4 Evaluation Framework (Automated)

- **Test Suite:** `tests/test_cases.json` (see repo) — run via Vapi web call API
- **CI Gate:** PTP rate > 30% on 50 synthetic calls, 0 debt-before-auth violations
- **Shadow Mode:** New prompt versions run on 10% traffic, compare metrics before full rollout

---

## Appendix A: Mermaid Architecture Diagram Source

```mermaid
sequenceDiagram
    autonumber
    actor Customer
    participant Telephony as Telephony / SIP
    participant Vapi as Vapi Engine
    participant STT as Deepgram STT (Nova-2)
    participant LLM as GPT-4o (Orchestrator)
    participant Server as Mock Webhook API
    participant TTS as ElevenLabs TTS

    Customer->>Telephony: Answers Call
    Telephony->>Vapi: Stream Audio (8kHz Opus)
    Vapi->>STT: Real-time Audio Stream
    STT-->>Vapi: Transcribed Text Stream (EN/HI)

    rect rgb(240, 240, 240)
        note over Vapi, LLM: AUTH PHASE (No Debt Disclosed)
        Vapi->>LLM: Conversation State + Transcript
        LLM-->>Vapi: Request Verification ("Last 4 PAN / DOB?")
        Vapi->>TTS: Synthesize Speech
        TTS-->>Customer: Play Audio
        Customer->>Vapi: Speaks ("1234")
        Vapi->>LLM: Transcript ("1234")
        LLM->>Server: Tool Call: verify_customer(ACC-88392, "1234")
        Server-->>LLM: Response: { verified: true, customer_name: "Rahul Sharma" }
    end

    rect rgb(220, 245, 220)
        note over Vapi, LLM: COLLECTIONS & NEGOTIATION PHASE
        LLM-->>Vapi: Disclose Debt & Ask PTP
        Vapi->>TTS: Audio Output ("₹8,499 overdue by 12 days...")
        TTS-->>Customer: Play Audio
        Customer->>Vapi: "I will pay this Friday."
        LLM->>Server: Tool Call: log_promise_to_pay(date: "2026-08-14", amount: 8499)
        Server-->>LLM: Response: { status: "SUCCESS", ptp_id: "PTP-9921" }
        LLM->>Server: Tool Call: send_payment_link(channel: "SMS")
        Server-->>LLM: Response: { link_sent: true }
    end

    LLM-->>Vapi: Final Polite Goodbye
    Vapi->>Customer: End Call
```

---

## Appendix B: State Machine Mermaid

```mermaid
stateDiagram-v2
    [*] --> INIT
    INIT --> GREETING: Call Connected
    
    GREETING --> AUTH_PENDING: "Yes, this is Rahul"
    GREETING --> WRONG_PERSON: "No/Wrong number"
    GREETING --> NO_RESPONSE: Timeout/Voicemail
    
    AUTH_PENDING --> AUTHENTICATED: verify_customer() = true
    AUTH_PENDING --> AUTH_FAILED: verify_customer() = false (retry 1x)
    AUTH_FAILED --> WRONG_PERSON: 2nd failure
    
    AUTHENTICATED --> NEGOTIATION: Debt Disclosed
    
    NEGOTIATION --> PTP_COLLECTED: Promise to Pay
    NEGOTIATION --> HARDSHIP: Cannot Pay
    NEGOTIATION --> ALREADY_PAID: Claims Paid
    NEGOTIATION --> DISPUTE: Disputes Amount
    NEGOTIATION --> DNC: Do Not Call
    NEGOTIATION --> ABUSIVE: Abusive Language
    NEGOTIATION --> CALLBACK: Request Callback
    
    PTP_COLLECTED --> ACTION_EXECUTION: log_promise_to_pay + send_payment_link
    HARDSHIP --> ACTION_EXECUTION: escalate_to_agent(HARDSHIP)
    ALREADY_PAID --> ACTION_EXECUTION: mark_disposition(ALREADY_PAID)
    DISPUTE --> ACTION_EXECUTION: escalate_to_agent(DISPUTE)
    DNC --> ACTION_EXECUTION: mark_disposition(DO_NOT_CALL)
    ABUSIVE --> ACTION_EXECUTION: mark_disposition(ABUSIVE_TERMINATED)
    CALLBACK --> ACTION_EXECUTION: mark_disposition(CALLBACK_SCHEDULED)
    WRONG_PERSON --> ACTION_EXECUTION: mark_disposition(WRONG_PERSON)
    NO_RESPONSE --> ACTION_EXECUTION: mark_disposition(NO_RESPONSE)
    
    ACTION_EXECUTION --> WRAP_UP: Tool Response Received
    WRAP_UP --> CALL_ENDED: mark_disposition Logged
    CALL_ENDED --> [*]
```

---

**End of HLD Document**