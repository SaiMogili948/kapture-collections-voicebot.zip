# Demo Recording Script — Maya Collections Voicebot

Use this script to record your 2–4 minute Loom (or Vapi call recording) for Task 2.
It covers the two required paths: **happy path (Promise-to-Pay)** and **edge case (Already Paid)**,
plus a bonus 30-second **Do-Not-Call** clip that shows compliance guardrails.

## Pre-flight

1. Mock server running: `cd mock-server && npm start`
2. ngrok tunnel live: `ngrok http 3000` → copy HTTPS URL
3. Vapi assistant created (from `vapi/vapi_assistant_config.json`) with tool webhooks
   pointed at `https://<your-ngrok>.ngrok-free.app/webhook`
4. Keep the terminal with the mock server visible in the recording frame —
   it prints every tool call, which proves the tools are actually wired.
5. For live testing you can call the Vapi number directly, or use the
   **Web Call** button in the Vapi dashboard.

---

## Part 1 — Happy Path: Promise-to-Pay (≈ 60–90s)

> Goal: show greeting → auth gate → debt disclosure → PTP → payment link → disposition.

| Turn | Speaker | Script |
|------|---------|--------|
| 1 | **Maya** | "Hello, this is Maya calling from Kapture Finance. This call may be recorded for quality and compliance purposes. Am I speaking with Mr. Rahul Sharma?" |
| 2 | **You (Rahul)** | "Yes, this is Rahul." |
| 3 | **Maya** | "For security purposes, could you please confirm the last 4 digits of your PAN card or your year of birth?" |
| 4 | **You** | "The last four digits are 1234." |
| 5 | **Maya** | "Thank you for verifying, Rahul. I'm calling regarding your Kapture Finance personal loan. An EMI of ₹8,499 is currently overdue by 12 days. Can you make a payment towards this today?" |
| 6 | **You** | "I can pay the full amount this Friday." |
| 7 | **Maya** | "Great, so you'll pay ₹8,499 by Friday. Let me log that and send you a payment link." |

**Server console should show (capture in frame):**

```
[Tool Call] verify_customer {"account_id":"ACC-88392","verification_code":"1234"}
[Tool Call] log_promise_to_pay {"account_id":"ACC-88392","ptp_date":"this Friday","amount":8499}
[Tool Call] send_payment_link {"account_id":"ACC-88392","channel":"SMS"}
[Tool Call] mark_disposition {"account_id":"ACC-88392","status":"PTP_AGREED",...}
```

8. **Maya** closes: "I've logged your promise to pay and sent a payment link via SMS to your registered number… Thank you for your time today, Rahul. Have a great day ahead!"

**Narrator tip (if using Loom):** pause and point out that no debt amount was mentioned before the `verify_customer` tool returned success.

---

## Part 2 — Edge Case: Already Paid (≈ 45–60s)

> Goal: show the same auth gate, then graceful handling of an "already paid" claim.

| Turn | Speaker | Script |
|------|---------|--------|
| 1 | **Maya** | Greeting + identity confirmation (same as Part 1) |
| 2 | **You** | "Haan, main Rahul hoon." (Hinglish — shows bilingual support) |
| 3 | **Maya** | Verification prompt (Hindi/Hinglish okay) |
| 4 | **You** | "PAN ke last four digits 1234 hain." |
| 5 | **Maya** | Debt disclosure (bilingual) |
| 6 | **You** | "I already paid yesterday via UPI. Reference number is UPI123456." |
| 7 | **Maya** | "Thank you for letting us know. Bank processing typically takes 24–48 hours to reflect. If you have a reference number, please keep it handy. We'll update our records accordingly." |

**Server console should show:**

```
[Tool Call] verify_customer {"account_id":"ACC-88392","verification_code":"1234"}
[Tool Call] mark_disposition {"account_id":"ACC-88392","status":"ALREADY_PAID","notes":"Customer claims paid via UPI yesterday, ref UPI123456"}
```

8. **Maya** closes politely. **End call.**

---

## Part 3 (Bonus) — Do-Not-Call opt-out (≈ 30s)

| Turn | Speaker | Script |
|------|---------|--------|
| 1–4 | | Authenticate as in Part 1 |
| 5 | **You** | "Stop calling me. Put me on your do-not-call list." |
| 6 | **Maya** | "Understood. I will update our system to register your do-not-call request immediately. You will not receive further calls from us. Thank you." |

**Server console:** `[Tool Call] mark_disposition {"status":"DO_NOT_CALL",...}` → call ends immediately.

---

## Recording checklist

- [ ] Both tool-call logs visible in the terminal during the recording
- [ ] Debt amount appears only **after** verification (narrate this explicitly)
- [ ] Recording is 2–4 minutes total
- [ ] Upload to Loom → paste link into `README.md` → section "Demo Recording"

## If the bot misbehaves during recording

| Symptom | Likely cause | Fix |
|---------|--------------|-----|
| Debt mentioned pre-auth | Prompt states not respected | Re-upload `vapi/system_prompt.txt`, check STATE rules intact |
| Tools never fire | Webhook URL wrong / ngrok expired | Re-run ngrok, update tool server URLs, hit `/health` |
| Hindi not transcribed | Transcriber language | Set Deepgram `language: "multi"` (or `"hi"`) |
| Vapi 404 on tool call | Response format wrong | Mock server must reply `{ results: [{ toolCallId, result }] }` |