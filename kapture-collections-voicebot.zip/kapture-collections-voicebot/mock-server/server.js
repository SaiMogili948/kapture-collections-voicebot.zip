const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const PORT = process.env.PORT || 3000;

// Mock configuration (see .env.example). In production these come from the
// real collections database, not environment variables.
const MOCK_ACCOUNT_ID = process.env.MOCK_ACCOUNT_ID || 'ACC-88392';
const MOCK_CUSTOMER_NAME = process.env.MOCK_CUSTOMER_NAME || 'Rahul Sharma';
const MOCK_OVERDUE_AMOUNT = Number(process.env.MOCK_OVERDUE_AMOUNT || 8499);
const MOCK_DAYS_PAST_DUE = Number(process.env.MOCK_DAYS_PAST_DUE || 12);
const VALID_VERIFICATION_CODES = (process.env.VALID_VERIFICATION_CODES || '1234,1995')
  .split(',')
  .map((c) => c.trim());

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// In-memory store for call context (in production, use Redis/PostgreSQL)
const callSessions = new Map();

// Helper: Generate random ID
const genId = (prefix) => `${prefix}-${Math.floor(1000 + Math.random() * 9000)}`;

// Helper: Normalize date from natural language
function normalizeDate(input) {
  const today = new Date();
  const lower = input.toLowerCase().trim();

  if (lower === 'today') return today.toISOString().split('T')[0];
  if (lower === 'tomorrow') {
    const t = new Date(today);
    t.setDate(t.getDate() + 1);
    return t.toISOString().split('T')[0];
  }
  if (lower.includes('friday')) {
    const t = new Date(today);
    const dayDiff = (5 - t.getDay() + 7) % 7 || 7; // Next Friday
    t.setDate(t.getDate() + dayDiff);
    return t.toISOString().split('T')[0];
  }
  if (lower.includes('monday')) {
    const t = new Date(today);
    const dayDiff = (1 - t.getDay() + 7) % 7 || 7;
    t.setDate(t.getDate() + dayDiff);
    return t.toISOString().split('T')[0];
  }
  // Try parsing as ISO date
  const parsed = new Date(input);
  if (!isNaN(parsed.getTime())) return parsed.toISOString().split('T')[0];

  // Default to tomorrow
  const t = new Date(today);
  t.setDate(t.getDate() + 1);
  return t.toISOString().split('T')[0];
}

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Dispatch a single tool call and return its result object
function handleTool(name, args) {
  let result = {};

  switch (name) {
      case 'verify_customer': {
        const { account_id, verification_code } = args;
        const code = verification_code?.toString().trim() || '';

        // Guardrail: an empty code (LLM fired the tool before the customer
        // spoke) must NOT count as a failed attempt. Return an explicit
        // instruction so the model asks for the code and retries.
        if (!code) {
          result = {
            verified: false,
            attempt_counted: false,
            message:
              'No verification code received. Ask the customer for the last 4 digits of their PAN or their year of birth, then call verify_customer again.'
          };
          break;
        }

        const verified = VALID_VERIFICATION_CODES.includes(code);

        result = {
          verified,
          customer_name: verified ? MOCK_CUSTOMER_NAME : null,
          message: verified
            ? 'Identity verified successfully.'
            : 'Verification failed. Incorrect code. Please try again.'
        };
        break;
      }

      case 'log_promise_to_pay': {
        const { account_id, ptp_date, amount } = args;
        const normalizedDate = normalizeDate(ptp_date);

        result = {
          success: true,
          ptp_id: genId('PTP'),
          confirmed_date: normalizedDate,
          amount: Number(amount),
          raw_date_input: ptp_date
        };
        break;
      }

      case 'send_payment_link': {
        const { account_id, channel } = args;

        result = {
          success: true,
          message: `Payment link sent successfully via ${channel} to registered mobile number.`,
          link_id: genId('LINK'),
          channel
        };
        break;
      }

      case 'escalate_to_agent': {
        const { account_id, reason, summary } = args;

        result = {
          success: true,
          ticket_id: genId('TKT'),
          queue_position: Math.floor(Math.random() * 5) + 1,
          estimated_wait_seconds: Math.floor(Math.random() * 120) + 30,
          reason,
          summary
        };
        break;
      }

      case 'mark_disposition': {
        const { account_id, status, notes } = args;

        result = {
          success: true,
          disposition_logged: status,
          notes: notes || '',
          timestamp: new Date().toISOString()
        };
        break;
      }

      default:
        result = { success: false, message: `Unknown function: ${name}` };
    }

  return result;
}

// Main Vapi webhook endpoint
app.post('/webhook', (req, res) => {
  const { message } = req.body;

  console.log('\n=== WEBHOOK RECEIVED ===');
  console.log('Timestamp:', new Date().toISOString());
  console.log('Message type:', message?.type);

  // Handle Vapi tool calls. Vapi may batch MULTIPLE tool calls in one
  // webhook — respond with a result for every toolCallId.
  if (message && message.type === 'tool-calls') {
    const toolCalls = message.toolCalls || [];
    if (toolCalls.length === 0) {
      return res.status(400).json({ error: 'No tool call found' });
    }

    const response = { results: [] };

    for (const toolCall of toolCalls) {
      const { id: callId, function: func } = toolCall;
      const { name, arguments: argsStr } = func;
      let args;

      try {
        args = typeof argsStr === 'string' ? JSON.parse(argsStr) : argsStr;
      } catch (e) {
        console.error('Failed to parse tool arguments:', argsStr);
        response.results.push({
          toolCallId: callId,
          result: JSON.stringify({ success: false, message: 'Invalid tool arguments' })
        });
        continue;
      }

      console.log(`[Tool Call] ${name}`, JSON.stringify(args));
      const result = handleTool(name, args);
      response.results.push({ toolCallId: callId, result: JSON.stringify(result) });
    }

    console.log('[Tool Response]', JSON.stringify(response));
    return res.status(200).json(response);
  }

  // Handle other Vapi events (call.start, call.end, speech.update, etc.)
  if (message && message.type) {
    console.log(`[Vapi Event] ${message.type}`, JSON.stringify(message, null, 2));

    // Track call sessions for context
    if (message.type === 'call.start') {
      callSessions.set(message.call?.id, {
        startTime: new Date(),
        accountId: MOCK_ACCOUNT_ID,
        state: 'INIT'
      });
    }

    if (message.type === 'call.end') {
      callSessions.delete(message.call?.id);
    }

    return res.status(200).json({ status: 'acknowledged' });
  }

  // Fallback
  console.log('[Unknown Message]', JSON.stringify(req.body, null, 2));
  return res.status(200).json({ status: 'acknowledged' });
});

// Start server
app.listen(PORT, () => {
  console.log(`
╔════════════════════════════════════════════════════════════╗
║  Kapture Mock Collections Webhook Server                   ║
║  Running on http://localhost:${PORT}                          ║
║  Webhook endpoint: http://localhost:${PORT}/webhook          ║
║  Health check: http://localhost:${PORT}/health               ║
╚════════════════════════════════════════════════════════════╝
  `);
});

module.exports = app;