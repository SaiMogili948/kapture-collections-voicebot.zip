#!/usr/bin/env node
/**
 * Builds vapi/vapi_assistant_config.json from:
 *   - vapi/system_prompt.txt   (system prompt)
 *   - vapi/tool_definitions.json (tool schemas)
 *
 * Usage:
 *   node scripts/build_assistant_config.js
 *   VAPI_TOOL_SERVER_URL=https://abc.ngrok-free.app/webhook node scripts/build_assistant_config.js
 *
 * The generated file can be posted to the Vapi API (POST /assistant) or pasted
 * into the Vapi dashboard under Advanced -> Import JSON.
 */

const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const systemPrompt = fs.readFileSync(path.join(ROOT, 'vapi', 'system_prompt.txt'), 'utf8');
const toolDefinitions = JSON.parse(
  fs.readFileSync(path.join(ROOT, 'vapi', 'tool_definitions.json'), 'utf8')
);

const TOOL_SERVER_URL =
  process.env.VAPI_TOOL_SERVER_URL || 'https://YOUR-NGROK-SUBDOMAIN.ngrok-free.app/webhook';

const tools = toolDefinitions.map((t) => ({
  ...t,
  server: { url: TOOL_SERVER_URL },
}));

const assistant = {
  name: 'Kapture Collections Agent - Maya',
  model: {
    provider: 'openai',
    model: 'gpt-4o',
    temperature: 0.1,
    messages: [{ role: 'system', content: systemPrompt }],
    tools,
  },
  voice: {
    provider: '11labs',
    voiceId: 'Sarah',
    model: 'eleven_turbo_v2_5',
  },
  transcriber: {
    provider: 'deepgram',
    model: 'nova-2',
    language: 'en-US',
  },
  firstMessage:
    'Hello, this is Maya calling from Kapture Finance. This call may be recorded for quality and compliance purposes. Am I speaking with Mr. Rahul Sharma?',
  endCallMessage: 'Thank you for your time today. Have a great day ahead!',
  endCallPhrases: ['Thank you for your time today, Rahul. Have a great day ahead!'],
  maxDurationSeconds: 300,
  metadata: {
    client: 'Kapture Finance',
    agent_persona: 'Maya',
    use_case: 'Outbound collections for overdue EMI',
    target_customer: 'Rahul Sharma',
    account_id: 'ACC-88392',
    overdue_amount_inr: 8499,
    days_past_due: 12,
    calling_window_ist: '08:00-19:00',
    generated_by: 'scripts/build_assistant_config.js',
  },
};

const outPath = path.join(ROOT, 'vapi', 'vapi_assistant_config.json');
fs.writeFileSync(outPath, JSON.stringify(assistant, null, 2) + '\n');

console.log(`Wrote ${path.relative(ROOT, outPath)}`);
console.log(`Tool server URL: ${TOOL_SERVER_URL}`);
console.log(`Tools wired: ${tools.map((t) => t.function.name).join(', ')}`);
