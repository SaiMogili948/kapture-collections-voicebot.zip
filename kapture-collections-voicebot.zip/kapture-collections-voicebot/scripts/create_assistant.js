#!/usr/bin/env node
/**
 * Creates the Kapture Maya assistant on Vapi via REST API.
 */
const https = require('https');
const fs = require('fs');
const path = require('path');

const API_KEY = 'bb8b0c0a-faea-4f36-a4aa-c33741f087a4';
const config = fs.readFileSync(path.join(__dirname, '..', 'vapi', 'vapi_assistant_config.json'), 'utf8');

const payload = Buffer.from(config);

const options = {
  hostname: 'api.vapi.ai',
  path: '/assistant',
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${API_KEY}`,
    'Content-Type': 'application/json',
    'Content-Length': payload.length,
  },
};

console.log('Creating assistant on Vapi...\n');

const req = https.request(options, (res) => {
  let data = '';
  res.on('data', (chunk) => (data += chunk));
  res.on('end', () => {
    if (res.statusCode === 201 || res.statusCode === 200) {
      const assistant = JSON.parse(data);
      console.log('✅ Assistant created successfully!\n');
      console.log(`   Name : ${assistant.name}`);
      console.log(`   ID   : ${assistant.id}`);
      console.log(`   URL  : https://dashboard.vapi.ai/assistants/${assistant.id}`);
      console.log('\nYour assistant "Maya" is live on Vapi. You can now make calls!');
    } else {
      console.error(`❌ API Error ${res.statusCode}:`);
      console.error(data);
    }
  });
});

req.on('error', (e) => {
  console.error('❌ Network error:', e.message);
});

req.write(payload);
req.end();
