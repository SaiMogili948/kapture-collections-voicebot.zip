#!/usr/bin/env node
/**
 * Tests if the localtunnel webhook is reachable from the internet (via Vapi).
 * Sends a health check and a sample tool call to the public URL.
 */
const https = require('https');

const TUNNEL_URL = 'https://early-clubs-juggle.loca.lt';

function get(path) {
  return new Promise((resolve, reject) => {
    https.get(`${TUNNEL_URL}${path}`, { headers: { 'bypass-tunnel-reminder': 'true' } }, (res) => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => resolve({ status: res.statusCode, body: data }));
    }).on('error', reject);
  });
}

function post(path, body) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const url = new URL(`${TUNNEL_URL}${path}`);
    const req = https.request({
      hostname: url.hostname,
      path: url.pathname,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(payload),
        'bypass-tunnel-reminder': 'true',
      },
    }, (res) => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => resolve({ status: res.statusCode, body: data }));
    });
    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

async function run() {
  console.log(`Testing tunnel: ${TUNNEL_URL}\n`);

  // 1. Health check
  try {
    const health = await get('/health');
    if (health.status === 200) {
      console.log('✅ /health reachable via tunnel:', health.body.trim());
    } else {
      console.log(`⚠️  /health returned HTTP ${health.status}:`);
      console.log(health.body.slice(0, 300));
    }
  } catch (e) {
    console.error('❌ /health failed:', e.message);
  }

  // 2. Webhook tool call
  try {
    const res = await post('/webhook', {
      message: {
        type: 'tool-calls',
        toolCalls: [{
          id: 'test-1',
          function: {
            name: 'verify_customer',
            arguments: JSON.stringify({ account_id: 'ACC-88392', verification_code: '1234' }),
          },
        }],
      },
    });
    if (res.status === 200) {
      console.log('✅ /webhook tool call successful:', res.body.slice(0, 200));
    } else {
      console.log(`⚠️  /webhook returned HTTP ${res.status}:`);
      console.log(res.body.slice(0, 500));
    }
  } catch (e) {
    console.error('❌ /webhook failed:', e.message);
  }
}

run();
