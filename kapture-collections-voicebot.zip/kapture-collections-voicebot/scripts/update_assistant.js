#!/usr/bin/env node
/**
 * Updates the Kapture Maya assistant on Vapi with a new webhook URL.
 */
const https = require('https');
const fs = require('fs');
const path = require('path');

const API_KEY = 'bb8b0c0a-faea-4f36-a4aa-c33741f087a4';
const ASSISTANT_ID = 'd2952e15-d0ac-403f-8550-26d1160e2311';
const NEW_WEBHOOK_URL = 'https://a06ddac161cf4ebc-152-57-21-182.serveousercontent.com/webhook';

// Read existing config and update all webhook URLs
const configPath = path.join(__dirname, '..', 'vapi', 'vapi_assistant_config.json');
let config = JSON.parse(fs.readFileSync(configPath, 'utf8'));

// Update all tool server URLs
config.model.tools.forEach(tool => {
  if (tool.server && tool.server.url) {
    tool.server.url = NEW_WEBHOOK_URL;
  }
});

// Save updated config
fs.writeFileSync(configPath, JSON.stringify(config, null, 2));
console.log('Updated local config with new webhook URL.\n');

const payload = Buffer.from(JSON.stringify(config));

const options = {
  hostname: 'api.vapi.ai',
  path: `/assistant/${ASSISTANT_ID}`,
  method: 'PATCH',
  headers: {
    'Authorization': `Bearer ${API_KEY}`,
    'Content-Type': 'application/json',
    'Content-Length': payload.length,
  },
};

console.log('Updating assistant on Vapi...\n');

const req = https.request(options, (res) => {
  let data = '';
  res.on('data', (chunk) => (data += chunk));
  res.on('end', () => {
    if (res.statusCode === 200 || res.statusCode === 201) {
      const assistant = JSON.parse(data);
      console.log('✅ Assistant updated successfully!\n');
      console.log(`   Name       : ${assistant.name}`);
      console.log(`   ID         : ${assistant.id}`);
      console.log(`   Webhook    : ${NEW_WEBHOOK_URL}`);
      console.log('\nYou can now test "Maya" on Vapi!');
    } else {
      console.error(`❌ API Error ${res.statusCode}:`);
      console.error(data);
    }
  });
});

req.on('error', (e) => {
  console.error('❌ Network error:', e.message);
});

req.write(payload);
req.end();
