#!/usr/bin/env node
/**
 * Headless end-to-end simulator: drives the REAL Vapi system prompt through an
 * LLM (via Ollama's OpenAI-compatible API) and routes tool calls through the
 * REAL mock webhook server over HTTP — the exact contract Vapi uses.
 *
 * This proves the prompt + tool schemas + server work together without
 * telephony. Usage:
 *
 *   node tests/headless_call_simulator.js [TC-002|TC-003|TC-004|TC-008]
 *
 * Env:
 *   OLLAMA_URL   (default http://localhost:11434/v1)
 *   OLLAMA_MODEL (default llama3.1:8b)
 *   MOCK_PORT    (default 3200)
 */

const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');
const http = require('http');

const ROOT = path.join(__dirname, '..');
const OLLAMA_URL = process.env.OLLAMA_URL || 'http://localhost:11434/v1';
const OLLAMA_MODEL = process.env.OLLAMA_MODEL || 'llama3.1:8b';
const MOCK_PORT = Number(process.env.MOCK_PORT || 3200);
const SERVER_ENTRY = path.join(ROOT, 'mock-server', 'server.js');

const systemPrompt = fs.readFileSync(path.join(ROOT, 'vapi', 'system_prompt.txt'), 'utf8');
const tools = JSON.parse(fs.readFileSync(path.join(ROOT, 'vapi', 'tool_definitions.json'), 'utf8'));

const SCENARIOS = {
  'TC-002': {
    name: 'Happy Path — Promise to Pay',
    turns: ['Yes, this is Rahul', 'My PAN ends in 1234', 'I can pay the full amount this Friday', 'Yes, that works'],
    expect: 'PTP_AGREED',
  },
  'TC-003': {
    name: 'Edge Case — Already Paid',
    turns: ['Haan main Rahul bol raha hoon', 'PAN number 1234 hai', 'Maine kal UPI se pay kar diya tha, reference UPI123456'],
    expect: 'ALREADY_PAID',
  },
  'TC-004': {
    name: 'Edge Case — Do Not Call',
    turns: ['Yes I am Rahul', 'Code is 1234', 'Stop calling me, put me on your do not call list immediately!'],
    expect: 'DO_NOT_CALL',
  },
  'TC-008': {
    name: 'Edge Case — Verification Failure',
    turns: ['Yes I am Rahul', 'My PAN is 5678', 'Umm, maybe 9999?'],
    expect: 'WRONG_PERSON',
  },
};

function ollama(messages, toolsActive) {
  const payload = {
    model: OLLAMA_MODEL,
    messages,
    temperature: 0.1,
    max_tokens: 300,
    stream: false,
  };
  if (toolsActive) payload.tools = tools;
  return new Promise((resolve, reject) => {
    const body = JSON.stringify(payload);
    const req = http.request(
      {
        host: 'localhost',
        port: 11434,
        path: '/v1/chat/completions',
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) },
      },
      (res) => {
        let data = '';
        res.on('data', (c) => (data += c));
        res.on('end', () => {
          try { resolve(JSON.parse(data)); } catch (e) { reject(new Error(`LLM bad response: ${data.slice(0, 300)}`)); }
        });
      }
    );
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

function callWebhook(toolCall) {
  return new Promise((resolve, reject) => {
    const payload = {
      message: {
        type: 'tool-calls',
        toolCalls: [
          {
            id: toolCall.id,
            function: { name: toolCall.function.name, arguments: typeof toolCall.function.arguments === 'string' ? toolCall.function.arguments : JSON.stringify(toolCall.function.arguments) },
          },
        ],
      },
    };
    const body = JSON.stringify(payload);
    const req = http.request(
      {
        host: 'localhost',
        port: MOCK_PORT,
        path: '/webhook',
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) },
      },
      (res) => {
        let data = '';
        res.on('data', (c) => (data += c));
        res.on('end', () => {
          try {
            const parsed = JSON.parse(data);
            const entry = parsed.results?.[0];
            resolve(entry ? JSON.parse(entry.result) : parsed);
          } catch (e) { reject(new Error(`Webhook bad response: ${data.slice(0, 300)}`)); }
        });
      }
    );
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

function waitForHealth(timeoutMs = 10000) {
  return new Promise((resolve, reject) => {
    const start = Date.now();
    const poll = () => {
      http
        .get(`http://localhost:${MOCK_PORT}/health`, (res) => {
          res.resume();
          if (res.statusCode === 200) return resolve();
          if (Date.now() - start > timeoutMs) return reject(new Error('Server health timeout'));
          setTimeout(poll, 250);
        })
        .on('error', () => {
          if (Date.now() - start > timeoutMs) return reject(new Error('Server did not start'));
          setTimeout(poll, 250);
        });
    };
    poll();
  });
}

const TERMINAL_STATUSES = new Set(['PTP_AGREED', 'ALREADY_PAID', 'DISPUTED', 'HARDSHIP_ESCALATED', 'WRONG_PERSON', 'DO_NOT_CALL', 'NO_RESPONSE', 'VOICEMAIL', 'ABUSIVE_TERMINATED', 'CALLBACK_SCHEDULED']);

async function runScenario(key) {
  const sc = SCENARIOS[key];
  if (!sc) throw new Error(`Unknown scenario ${key}. Available: ${Object.keys(SCENARIOS).join(', ')}`);
  console.log(`\n=== ${key}: ${sc.name} ===\n`);

  const messages = [{ role: 'system', content: systemPrompt }];
  const firstMessage = 'Hello, this is Maya calling from Kapture Finance. This call may be recorded for quality and compliance purposes. Am I speaking with Mr. Rahul Sharma?';
  messages.push({ role: 'assistant', content: firstMessage });
  console.log(`MAYA > ${firstMessage}`);

  const toolLog = [];
  let disposition = null;

  for (const turn of sc.turns) {
    messages.push({ role: 'user', content: `(Customer) ${turn}` });
    console.log(`CUST > ${turn}`);

    for (let guard = 0; guard < 12; guard++) {
      const resp = await ollama(messages, true);
      const msg = resp.choices?.[0]?.message;
      if (!msg) throw new Error('LLM returned empty message');

      const toolCalls = msg.tool_calls || [];
      if (toolCalls.length === 0) {
        const text = (msg.content || '').trim();
        if (text) {
          console.log(`MAYA > ${text.replace(/\n+/g, ' ')}`);
          messages.push({ role: 'assistant', content: text });
        }
        break;
      }

      messages.push({ role: 'assistant', content: msg.content || '', tool_calls: toolCalls });
      for (const tc of toolCalls) {
        const fn = tc.function;
        const argsStr = typeof fn.arguments === 'string' ? fn.arguments : JSON.stringify(fn.arguments);
        let args;
        try { args = JSON.parse(argsStr); } catch { args = { raw: argsStr }; }
        const result = await callWebhook(tc);
        console.log(`  [tool] ${fn.name}(${JSON.stringify(args)}) -> ${JSON.stringify(result).slice(0, 140)}`);
        toolLog.push({ name: fn.name, args, result });
        if (fn.name === 'mark_disposition') disposition = result.disposition_logged;
        messages.push({ role: 'tool', tool_call_id: tc.id, content: JSON.stringify(result) });
      }
      if (disposition && TERMINAL_STATUSES.has(disposition)) return { toolLog, disposition, messages };
    }
  }
  return { toolLog, disposition, messages };
}

async function main() {
  const key = process.argv[2] || 'TC-002';
  let server = null;

  // Reuse a server already listening on MOCK_PORT (e.g. a live/deployed one);
  // otherwise spawn the mock server ourselves.
  let alreadyUp = false;
  try { await waitForHealth(); alreadyUp = true; } catch {}
  if (!alreadyUp) {
    server = spawn(process.execPath, [SERVER_ENTRY], { env: { ...process.env, PORT: String(MOCK_PORT) }, stdio: 'ignore' });
    await waitForHealth();
  }
  console.log(`[setup] ${alreadyUp ? `reusing server on :${MOCK_PORT}` : `spawned mock server on :${MOCK_PORT}`}`);

  try {
    const { toolLog, disposition } = await runScenario(key);
    console.log(`\nDISPOSITION LOGGED: ${disposition || 'NONE (call did not reach terminal disposition)'}`);
    if (disposition) console.log(`TOOL SEQUENCE: ${toolLog.map((t) => t.name).join(' -> ')}`);
  } catch (err) {
    console.error(`\n[simulator error] ${err.message}`);
    process.exitCode = 1;
  } finally {
    if (server) server.kill();
  }
}

main();
