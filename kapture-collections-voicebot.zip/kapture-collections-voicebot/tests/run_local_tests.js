#!/usr/bin/env node
/**
 * Local end-to-end test harness for the Kapture mock webhook server.
 *
 * Spawns the server on a test port, fires the exact `tool-calls` message
 * shape Vapi sends, and asserts on the response format and values.
 *
 * Usage:
 *   node tests/run_local_tests.js
 *
 * Exit code 0 = all passed, 1 = failures.
 */

const { spawn } = require('child_process');
const http = require('http');

const PORT = process.env.TEST_PORT || 3199;
const SERVER_ENTRY = require('path').join(__dirname, '..', 'mock-server', 'server.js');

const results = [];
const toolCall = (id, name, args) => ({
  message: {
    type: 'tool-calls',
    toolCalls: [
      {
        id,
        function: { name, arguments: typeof args === 'string' ? args : JSON.stringify(args) },
      },
    ],
  },
});

function post(path, body) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = http.request(
      { host: 'localhost', port: PORT, path, method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) } },
      (res) => {
        let data = '';
        res.on('data', (c) => (data += c));
        res.on('end', () => {
          let json;
          try { json = JSON.parse(data); } catch { return reject(new Error(`Non-JSON response: ${data}`)); }
          resolve({ status: res.statusCode, body: json });
        });
      }
    );
    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

function waitForHealth(timeoutMs = 10000) {
  return new Promise((resolve, reject) => {
    const start = Date.now();
    const poll = () => {
      http
        .get(`http://localhost:${PORT}/health`, (res) => {
          res.resume();
          if (res.statusCode === 200) return resolve();
          if (Date.now() - start > timeoutMs) return reject(new Error('Server health check timeout'));
          setTimeout(poll, 250);
        })
        .on('error', () => {
          if (Date.now() - start > timeoutMs) return reject(new Error('Server did not start'));
          setTimeout(poll, 250);
        });
    };
    poll();
  });
}

function check(name, cond, detail = '') {
  results.push({ name, pass: !!cond, detail });
}

function parseResult(res) {
  const entry = res.body.results?.[0];
  if (!entry || !entry.toolCallId || typeof entry.result !== 'string') return null;
  return JSON.parse(entry.result);
}

async function run() {
  const server = spawn(process.execPath, [SERVER_ENTRY], { env: { ...process.env, PORT: String(PORT) }, stdio: ['ignore', 'pipe', 'pipe'] });
  let serverLog = '';
  server.stdout.on('data', (d) => (serverLog += d));
  server.stderr.on('data', (d) => (serverLog += d));

  try {
    await waitForHealth();
    console.log(`[setup] mock server up on :${PORT}\n`);

    // 1. verify_customer — valid code
    let res = await post('/webhook', toolCall('call-1', 'verify_customer', { account_id: 'ACC-88392', verification_code: '1234' }));
    let out = parseResult(res);
    check('verify_customer 200', res.status === 200);
    check('verify_customer toolCallId echo', res.body.results?.[0]?.toolCallId === 'call-1');
    check('verify_customer success', out?.verified === true && out?.customer_name === 'Rahul Sharma', JSON.stringify(out));

    // 2. verify_customer — invalid code
    res = await post('/webhook', toolCall('call-2', 'verify_customer', { account_id: 'ACC-88392', verification_code: '0000' }));
    out = parseResult(res);
    check('verify_customer reject', out?.verified === false, JSON.stringify(out));

    // 2b. verify_customer — empty code (LLM fired tool too early): must NOT
    // count as a failed attempt; must instruct the model to ask for the code.
    res = await post('/webhook', toolCall('call-2b', 'verify_customer', { account_id: 'ACC-88392', verification_code: '' }));
    out = parseResult(res);
    check('verify_customer empty code guardrail', out?.verified === false && out?.attempt_counted === false && /ask the customer/i.test(out?.message || ''), JSON.stringify(out));

    // 3. log_promise_to_pay — natural language date
    res = await post('/webhook', toolCall('call-3', 'log_promise_to_pay', { account_id: 'ACC-88392', ptp_date: 'this Friday', amount: 8499 }));
    out = parseResult(res);
    const isIso = out && /^\d{4}-\d{2}-\d{2}$/.test(out.confirmed_date);
    check('log_promise_to_pay returns ISO date', out?.success === true && isIso, JSON.stringify(out));

    // 4. send_payment_link
    res = await post('/webhook', toolCall('call-4', 'send_payment_link', { account_id: 'ACC-88392', channel: 'SMS' }));
    out = parseResult(res);
    check('send_payment_link success', out?.success === true && !!out.link_id, JSON.stringify(out));

    // 5. escalate_to_agent
    res = await post('/webhook', toolCall('call-5', 'escalate_to_agent', { account_id: 'ACC-88392', reason: 'DISPUTE', summary: 'Customer disputes amount' }));
    out = parseResult(res);
    check('escalate_to_agent success', out?.success === true && !!out.ticket_id, JSON.stringify(out));

    // 6. mark_disposition — every allowed status
    const statuses = ['PTP_AGREED', 'ALREADY_PAID', 'DISPUTED', 'HARDSHIP_ESCALATED', 'WRONG_PERSON', 'DO_NOT_CALL', 'NO_RESPONSE', 'VOICEMAIL', 'ABUSIVE_TERMINATED', 'CALLBACK_SCHEDULED'];
    let allDispositionsOk = true;
    for (const s of statuses) {
      res = await post('/webhook', toolCall(`call-${s}`, 'mark_disposition', { account_id: 'ACC-88392', status: s, notes: 'test' }));
      out = parseResult(res);
      if (!out || out.success !== true || out.disposition_logged !== s) allDispositionsOk = false;
    }
    check('mark_disposition all 10 statuses', allDispositionsOk);

    // 7. unknown function — graceful
    res = await post('/webhook', toolCall('call-7', 'unknown_fn', {}));
    out = parseResult(res);
    check('unknown function graceful', out?.success === false && !!out.message, JSON.stringify(out));

    // 8. call.start / call.end events ack
    res = await post('/webhook', { message: { type: 'call.start', call: { id: 'c_evt' } } });
    check('call.start ack', res.status === 200 && res.body.status === 'acknowledged');
    res = await post('/webhook', { message: { type: 'call.end', call: { id: 'c_evt' } } });
    check('call.end ack', res.status === 200 && res.body.status === 'acknowledged');

    // 9. batched tool calls (Vapi sends multiple toolCalls in one webhook) —
    //    every call in the batch must get its own result entry.
    res = await post('/webhook', {
      message: {
        type: 'tool-calls',
        toolCalls: [
          { id: 'b1', function: { name: 'verify_customer', arguments: '{"account_id":"ACC-88392","verification_code":"1234"}' } },
          { id: 'b2', function: { name: 'log_promise_to_pay', arguments: '{"account_id":"ACC-88392","ptp_date":"this Friday","amount":8499}' } },
          { id: 'b3', function: { name: 'mark_disposition', arguments: '{"account_id":"ACC-88392","status":"PTP_AGREED"}' } },
        ],
      },
    });
    const batchResults = res.body.results || [];
    const batchIds = batchResults.map((r) => r.toolCallId).join(',');
    const b1 = batchResults[0] && JSON.parse(batchResults[0].result);
    const b3 = batchResults[2] && JSON.parse(batchResults[2].result);
    check('batched tool calls all answered', res.status === 200 && batchResults.length === 3 && batchIds === 'b1,b2,b3');
    check('batched results correct', b1?.verified === true && b3?.disposition_logged === 'PTP_AGREED', JSON.stringify(batchResults));
  } catch (err) {
    console.error('[fatal]', err.message);
    console.error(serverLog.slice(-2000));
    server.kill();
    process.exit(1);
  } finally {
    server.kill();
  }

  const failed = results.filter((r) => !r.pass);
  console.log('─'.repeat(62));
  for (const r of results) console.log(`  ${r.pass ? 'PASS' : 'FAIL'}  ${r.name}${r.detail ? '  →  ' + r.detail : ''}`);
  console.log('─'.repeat(62));
  console.log(`${results.length - failed.length}/${results.length} checks passed`);
  process.exit(failed.length ? 1 : 0);
}

run();
